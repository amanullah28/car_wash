describe("car washer registration", ()=>{
    
})