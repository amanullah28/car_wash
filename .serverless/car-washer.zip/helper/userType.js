module.exports =  {
    ADMIN: 1,
    CAR_WASHER: 2, 
    CUSTOMER: 3
}
