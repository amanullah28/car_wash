const jwt = require('jsonwebtoken');

const getResponseHeader = () => {
    return {
        'Access-Control-Allow-Origin': '*'
    }
}

const getAccessToken = (user) => {
    return jwt.sign({
        id: user.userId,
        email: user.emai,
        name: user.name
    }, "secretttt");
}

const decodeToken = (token)=> {
    try{
         let tokenVal = jwt.verify(token, "secretttt");
         return tokenVal;
    } catch(err) {
        console.log(err);
        return err;
    }
}

const generatePolicy = (user, effect, resource) => {
    const authResponse = {
        principalId: user.userId || 'anonymous'
    };

    if (effect && resource) {
        const policyDocument = {
            Version: '2012-10-17',
            Statement: [{
                Action: 'execute-api:Invoke',
                Effect: effect,
                Resource: resource
            }]
        };

        authResponse.policyDocument = policyDocument;
    }

    authResponse.context = {
        id: user.userId,
        email: user.email,
        name: user.name
    };
    return authResponse;
};

// export const authorizerFun = (event, context) => {
//     const authorizationToken = event.authorizationToken;

//     console.log(authorizationToken);

//     switch (authorizationToken) {
//         case 'manager':
//             context.succeed(generatePolicy({
//                 id: 1,
//                 role: 'MANAGER'
//             }, 'Allow', '*'));
//             break;
//         case 'tenant':
//             context.succeed(generatePolicy({
//                 id: 2,
//                 role: 'TENANT'
//             }, 'Allow', '*'));
//             break;
//         default:
//             context.fail('error');
//     }
// };


module.exports = {
    getResponseHeader
}